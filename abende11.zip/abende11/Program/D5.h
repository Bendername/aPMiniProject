#pragma once
#include "D3.h"
class D5 :
	public D3
{
public:
	D5();
	~D5();
};

